/**
 * 
 */
/**
 * 
 */
module crudemjava {
	requires java.sql;
	requires mysql.connector;
	
}